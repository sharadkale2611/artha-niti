
import {
  Directive,
  ElementRef,
  HostListener,
  Input,
  OnDestroy,
  Renderer2
} from '@angular/core';

import {
  MarathiTransliterationService
} from '../services/marathi-transliteration.service';

@Directive({
  selector: '[appMarathiTyping]',
  standalone: true
})
export class MarathiTypingDirective implements OnDestroy {

  @Input() appMarathiTyping = false;

  private dropdown?: HTMLElement;
  private suggestions: string[] = [];
  private currentWord = '';
  private startPosition = 0;
  private outsideClick?: () => void;

  constructor(
    private element: ElementRef<HTMLInputElement>,
    private renderer: Renderer2,
    private service: MarathiTransliterationService
  ) {}

  @HostListener('input')
  onInput(): void {
    if (!this.appMarathiTyping) {
      this.removeDropdown();
      return;
    }

    const input = this.element.nativeElement;
    const cursor = input.selectionStart ?? input.value.length;
    const before = input.value.substring(0, cursor);
    const match = before.match(/([a-zA-Z]+)$/);

    if (!match) {
      this.removeDropdown();
      return;
    }

    this.currentWord = match[1];
    this.startPosition = cursor - this.currentWord.length;

    this.suggestions = this.service.getSuggestions(
      this.currentWord
    );

    this.showDropdown();
  }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent): void {
    if (!this.appMarathiTyping) return;

    const input = this.element.nativeElement;

    if (event.key === ' ' && !event.isComposing) {
      const cursor = input.selectionStart ?? input.value.length;
      const before = input.value.substring(0, cursor);
      const match = before.match(/([a-zA-Z]+)$/);

      if (match) {
        event.preventDefault();
        this.selectWord(this.service.convertToMarathi(match[1]));
      }
    }

    if (event.key === 'Escape') {
      this.removeDropdown();
    }
  }

  private showDropdown(): void {
    this.removeDropdown();

    if (!this.suggestions.length) return;

    const input = this.element.nativeElement;

    this.dropdown = this.renderer.createElement('div');

    this.renderer.setStyle(this.dropdown, 'position', 'absolute');
    this.renderer.setStyle(this.dropdown, 'background', '#fff');
    this.renderer.setStyle(this.dropdown, 'border', '1px solid #ddd');
    this.renderer.setStyle(this.dropdown, 'borderRadius', '5px');
    this.renderer.setStyle(this.dropdown, 'boxShadow', '0 3px 10px #0002');
    this.renderer.setStyle(this.dropdown, 'zIndex', '9999');
    this.renderer.setStyle(this.dropdown, 'minWidth', input.offsetWidth + 'px');

    this.suggestions.forEach((word) => {
      const item = this.renderer.createElement('div');

      this.renderer.setProperty(item, 'textContent', word);
      this.renderer.setStyle(item, 'padding', '9px 12px');
      this.renderer.setStyle(item, 'cursor', 'pointer');

      this.renderer.listen(item, 'mousedown', (event: MouseEvent) => {
        event.preventDefault();
        this.selectWord(word);
      });

      this.renderer.appendChild(this.dropdown, item);
    });

    const rect = input.getBoundingClientRect();

    this.renderer.setStyle(this.dropdown, 'left', rect.left + window.scrollX + 'px');
    this.renderer.setStyle(this.dropdown, 'top', rect.bottom + window.scrollY + 'px');

    this.renderer.appendChild(document.body, this.dropdown);
  }

  private selectWord(word: string): void {
    const input = this.element.nativeElement;
    const value = input.value;
    const cursor = input.selectionStart ?? value.length;

    const before = value.substring(0, cursor);
    const match = before.match(/([a-zA-Z]+)$/);

    if (!match) return;

    const start = cursor - match[1].length;
    const after = value.substring(cursor);
    const separator = after.startsWith(' ') ? '' : ' ';

    const newValue =
      value.substring(0, start) +
      word +
      separator +
      after;

    this.renderer.setProperty(input, 'value', newValue);

    input.dispatchEvent(new Event('input', { bubbles: true }));

    const newCursor =
      start + word.length + (separator ? separator.length : 1);

    input.setSelectionRange(newCursor, newCursor);

    this.removeDropdown();
    input.focus();
  }

  private removeDropdown(): void {
    if (this.dropdown) {
      this.renderer.removeChild(document.body, this.dropdown);
      this.dropdown = undefined;
    }
  }

  ngOnDestroy(): void {
    this.removeDropdown();
  }
}
