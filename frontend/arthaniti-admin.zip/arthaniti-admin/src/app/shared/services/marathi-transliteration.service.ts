import { Injectable } from '@angular/core';

import {
  transliterateWord,
  getSuggestions
} from 'marathi-transliterate';

@Injectable({
  providedIn: 'root'
})
export class MarathiTransliterationService {

  convertToMarathi(word: string): string {
    if (!word.trim()) {
      return '';
    }

    return transliterateWord(word);
  }

  getSuggestions(word: string): string[] {
    if (!word.trim()) {
      return [];
    }

    const suggestions: string[] = getSuggestions(word);

    return [...new Set(suggestions)];
  }
}