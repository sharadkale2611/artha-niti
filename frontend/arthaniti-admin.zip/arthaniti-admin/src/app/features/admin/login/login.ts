import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule],
  template: `
    <main class="login-page">
      <form class="login-card" [formGroup]="form" (ngSubmit)="submit()" novalidate>
        <img class="brand-logo" src="assets/images/arthaniti-logo.svg" alt="ArthaNiti" />
        <h1>ArthaNiti</h1>
        <p class="subtitle">Chartered Accountant Portal</p>

        <label for="email">Email</label>
        <input id="email" type="email" formControlName="email" autocomplete="username" />

        <label for="password">Password</label>
        <input
          id="password"
          type="password"
          formControlName="password"
          autocomplete="current-password"
        />

        @if (error()) {
          <p class="error" role="alert">{{ error() }}</p>
        }

        <button type="submit" [disabled]="form.invalid || submitting()">Sign in</button>
      </form>
    </main>
  `,
  styles: `
    .login-page {
      min-height: 100vh;
      display: grid;
      place-items: center;
      background: linear-gradient(135deg, #17324d 0%, #1f7a8c 100%);
      padding: 1rem;
    }

    .login-card {
      width: min(22rem, 100%);
      display: grid;
      gap: 0.75rem;
      padding: 2rem;
      background: #fff;
      border-radius: 0.5rem;
      box-shadow: 0 0.5rem 2rem rgba(0, 0, 0, 0.12);
    }

    .brand-logo {
      width: 72px;
      height: 72px;
      justify-self: center;
      margin-bottom: 0.25rem;
    }

    h1 {
      margin: 0;
      text-align: center;
      color: #17324d;
    }

    .subtitle {
      margin: -0.5rem 0 0.5rem;
      text-align: center;
      color: #617181;
      font-size: 0.875rem;
    }

    input,
    button {
      min-height: 2.75rem;
      border-radius: 0.25rem;
    }

    input {
      border: 1px solid #cbd5df;
      padding: 0 0.75rem;
    }

    button {
      border: 0;
      background: #17324d;
      color: #fff;
      cursor: pointer;
    }

    button:disabled {
      cursor: not-allowed;
      opacity: 0.65;
    }

    .error {
      color: #b91c1c;
      margin: 0;
    }
  `,
})
export class Login {
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);

  readonly submitting = signal(false);
  readonly error = signal('');

  readonly form = new FormGroup({
    email: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.email],
    }),
    password: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required],
    }),
  });

  submit(): void {
    if (this.form.invalid || this.submitting()) {
      this.form.markAllAsTouched();
      return;
    }

    this.submitting.set(true);
    this.error.set('');

    this.authService.login(this.form.getRawValue()).subscribe({
      next: () => void this.router.navigate(['/dashboard']),
      error: (error: unknown) => {
        this.submitting.set(false);
        this.error.set(error instanceof Error ? error.message : 'Login failed.');
      },
    });
  }
}
